# Trade / Sale

Items potentially available for trade or sale.

!!! warning
    Keep private pricing, storage locations, and personal seller notes out of the public site.
