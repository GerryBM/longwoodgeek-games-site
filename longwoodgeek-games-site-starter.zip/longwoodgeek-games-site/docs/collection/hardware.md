# Hardware

Hardware inventory notes for consoles, computers, controllers, drives, adapters, and restoration targets.
