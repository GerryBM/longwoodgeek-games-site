# Collection Overview

This section tracks the public-facing view of the LongwoodGeek gaming collection.

## Current Plan

The collection will begin as a Google Sheets-backed catalog while a cleaner CSV/static-site workflow is developed.

## Privacy Note

Public catalog views should not include purchase prices, storage locations, serial numbers, seller details, or private notes.
