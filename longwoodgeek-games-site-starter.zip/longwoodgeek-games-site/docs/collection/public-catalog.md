# Public Catalog

The public catalog will be linked or embedded here.

## Temporary Link

Add the public Google Sheets link here once the public-view tab is ready:

```text
PASTE_PUBLIC_SHEET_LINK_HERE
```

## Embed Placeholder

When ready, replace the placeholder below with the published Google Sheet iframe.

```html
<iframe
  src="PASTE_GOOGLE_SHEET_EMBED_URL_HERE"
  width="100%"
  height="800"
  style="border:0;">
</iframe>
```
