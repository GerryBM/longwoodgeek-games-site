# About This Site

LongwoodGeek Games is the public-facing home for Gerald Martin / LongwoodGeek's gaming collection, preservation notes, exhibits, and Gaming Historia work.

The goal is to document, preserve, contextualize, and share gaming history in a readable way.
