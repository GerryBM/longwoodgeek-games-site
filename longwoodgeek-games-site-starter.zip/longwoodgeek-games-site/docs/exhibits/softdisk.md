# Softdisk Archive

Notes on the Softdisk magazine disk collection and imaging/preservation progress.
