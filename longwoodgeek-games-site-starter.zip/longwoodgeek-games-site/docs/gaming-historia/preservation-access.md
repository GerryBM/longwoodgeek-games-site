# Preservation and Access

Notes on why preservation matters, how access changes over time, and what can be done to keep games playable and understandable.
