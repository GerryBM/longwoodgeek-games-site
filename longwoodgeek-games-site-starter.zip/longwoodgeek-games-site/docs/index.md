# LongwoodGeek Games

A living catalog of my gaming collection, preservation projects, exhibits, and research notes.

## Start Here

- [Collection Overview](collection/)
- [Public Catalog](collection/public-catalog.md)
- [Preservation Notes](preservation/)
- [Exhibits](exhibits/)
- [Gaming Historia](gaming-historia/)

!!! note
    This site is a work in progress. The collection data will begin as a linked or embedded Google Sheet while the public catalog workflow is refined.
