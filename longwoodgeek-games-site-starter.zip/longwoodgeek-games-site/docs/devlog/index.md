# Devlog

## Initial Site Scaffold

Created the LongwoodGeek Games MkDocs site scaffold for collection cataloging, preservation notes, and exhibits.
