# LongwoodGeek Games Site

Static MkDocs site for `games.longwoodgeek.net`.

## Build locally

```bash
pip install mkdocs-material
mkdocs serve
```

## Deploy

This site is intended for AWS Amplify Hosting using `amplify.yml`.
